import React, { useState, useEffect } from 'react';
import io from 'socket.io-client';
import axios from 'axios';

const socket = io('http://localhost:5000');

function App() {
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState([]);
  const [username, setUsername] = useState('');

  useEffect(() => {
    axios.get('http://localhost:5000/messages').then(res => {
      setMessages(res.data);
    });

    socket.on('receive_message', (data) => {
      setMessages(prev => [...prev, data]);
    });

    return () => socket.off('receive_message');
  }, []);

  const sendMessage = () => {
    if (message && username) {
      socket.emit('send_message', {
        username,
        content: message,
      });
      setMessage('');
    }
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>Realtime Chat App</h2>
      <input
        type="text"
        placeholder="Enter your name"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
      /><br /><br />
      <input
        type="text"
        placeholder="Enter a message"
        value={message}
        onChange={(e) => setMessage(e.target.value)}
      />
      <button onClick={sendMessage}>Send</button>
      <div>
        {messages.map((msg, index) => (
          <div key={index}><strong>{msg.username}:</strong> {msg.content}</div>
        ))}
      </div>
    </div>
  );
}

export default App;
